package com.example.sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText edtId, edtHoTen, edtLop, edtDiaChi, edtSdt;

    ListView lstView;

    List<SinhVien> sinhVienList;

    SinhVienAdapter adapter;

    SinhVienDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        anhxa();
    }

    public void anhxa(){

        edtId = findViewById(R.id.edtId);
        edtHoTen = findViewById(R.id.edtHoTen);
        edtLop = findViewById(R.id.edtLop);
        edtDiaChi = findViewById(R.id.edtDiaChi);
        edtSdt = findViewById(R.id.edtSdt);
        lstView = findViewById(R.id.lstView);

        sinhVienList = new ArrayList<>();

        adapter = new SinhVienAdapter();
    }

    public void btnThem(View view) {
        int id = Integer.valueOf(edtId.getText().toString().trim());
        String hoTen = edtHoTen.getText().toString().trim();
        String lop = edtLop.getText().toString().trim();
        String diaChi = edtDiaChi.getText().toString().trim();
        String sdt = edtSdt.getText().toString().trim();
    }

    public void btnSua(View view) {
        int id = Integer.valueOf(edtId.getText().toString().trim());
        String hoTen = edtHoTen.getText().toString().trim();
        String lop = edtLop.getText().toString().trim();
        String diaChi = edtDiaChi.getText().toString().trim();
        String sdt = edtSdt.getText().toString().trim();
    }

    public void btnXoa(View view) {
    }

    public void btnThoat(View view) {
    }
}