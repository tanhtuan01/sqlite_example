package com.example.sqlite;

public class SinhVien {
    
    public String id;
    
    private String hoTen;
    
    private String lop;
    
    private String diaChi;

    private String sdt;

    public String getId() {
        return id;
    }

    public String getHoTen() {
        return hoTen;
    }

    public String getLop() {
        return lop;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public String getSdt() {
        return sdt;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public SinhVien(String id, String hoTen, String lop, String diaChi, String sdt) {
        this.id = id;
        this.hoTen = hoTen;
        this.lop = lop;
        this.diaChi = diaChi;
        this.sdt = sdt;
    }

    public SinhVien() {
    }
}
