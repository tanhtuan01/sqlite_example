package com.example.sqlite;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class SinhVienAdapter extends BaseAdapter {

    ArrayList<SinhVien> list;
    LayoutInflater layoutInflater;
    Context context;
    static class ViewHolder{
        TextView id, hoten, lop, diachi, sdt;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return null ;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if(convertView == null){
            convertView = layoutInflater.inflate(R.layout.item_sinhvien,null);
            viewHolder = new ViewHolder();
            viewHolder.id = convertView.findViewById(R.id.txtId);
            viewHolder.diachi = convertView.findViewById(R.id.txtDiaChi);
            viewHolder.hoten = convertView.findViewById(R.id.txtHoTen);
            viewHolder.sdt = convertView.findViewById(R.id.txtSdt);
            viewHolder.lop = convertView.findViewById(R.id.txtLop);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        SinhVien sinhVien = this.list.get(position);
        viewHolder.id.setText(sinhVien.getId());
        viewHolder.hoten.setText(sinhVien.getHoTen());
        viewHolder.sdt.setText(sinhVien.getSdt());
        viewHolder.lop.setText(sinhVien.getLop());
        viewHolder.diachi.setText(sinhVien.getDiaChi());

        return convertView;
    }

}
