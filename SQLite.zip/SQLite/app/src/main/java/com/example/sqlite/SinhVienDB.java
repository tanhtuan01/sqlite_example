package com.example.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class SinhVienDB extends SQLiteOpenHelper {

    private static String DB_NAME = "DB_SINHVIEN";
    private static String TB_NAME = "TB_SINHVIEN";

    public static  String ID_COLMN = "id";
    private static String HOTEN_COLUMN = "hoten";

    private static  String LOP_COLUMN = "lop";

    private static String DIACHI_COLUMN = "diachi";

    private static String SDT_COLUMN = "sdt";

    public SinhVienDB(@Nullable Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table " + TB_NAME + " (id char(10) primary key, hoten char(30), lop char(7), diachi char(120), sdt char(11))";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void addSinhVien(SinhVien sinhVien){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ID_COLMN, sinhVien.getId());
        values.put(HOTEN_COLUMN, sinhVien.getHoTen());
        values.put(LOP_COLUMN, sinhVien.getLop());
        values.put(DIACHI_COLUMN, sinhVien.getDiaChi());
        values.put(SDT_COLUMN, sinhVien.getSdt());

        db.insert(TB_NAME, null, values);
        db.close();
    }

    public void updateSinhVien(SinhVien sinhVien){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ID_COLMN, sinhVien.getId());
        values.put(HOTEN_COLUMN, sinhVien.getHoTen());
        values.put(LOP_COLUMN, sinhVien.getLop());
        values.put(DIACHI_COLUMN, sinhVien.getDiaChi());
        values.put(SDT_COLUMN, sinhVien.getSdt());

        db.update(TB_NAME, values, ID_COLMN + " = ?", new String[]{sinhVien.getId()});
        db.close();
    }
    public void deleteSinhVien(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TB_NAME, ID_COLMN + " = ?", new String[]{id});
        db.close();
    }


    public SinhVien getSinhVien(String id){
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TB_NAME, null, ID_COLMN + " = ?", new String[]{id}, null, null, null);
        if(cursor != null){
            cursor.moveToFirst();
        }

        SinhVien sinhVien = new SinhVien(
                cursor.getString(0),
                cursor.getString(1),
                cursor.getString(2),
                cursor.getString(3),
                cursor.getString(4)
        );

        return  sinhVien;
    }


    public List<SinhVien> listSinhVien(){
        List<SinhVien> list = new ArrayList<SinhVien>();

        String sql = "select * from " + TB_NAME;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql, null);

        while (cursor.isAfterLast() == false){
            SinhVien sinhVien = new SinhVien(
                    cursor.getString(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4)
            );
            list.add(sinhVien);
            cursor.moveToNext();
        }
        return list;
    }

    public void insertValues(){

        SQLiteDatabase db = this.getWritableDatabase();

        String sql = "insert into " + TB_NAME + " values ('sv001','Nguyen Van A','dh10c3','HN','123')," +
                "('sv002','Nguyen Van B','dh10c3','HN','123')," +
                "('sv003','Nguyen Van C','dh10c3','HN','123')" ;

        db.execSQL(sql);
        db.close();

    }

}
